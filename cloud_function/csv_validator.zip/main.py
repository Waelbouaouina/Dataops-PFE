import os
import io
import csv
import json
import logging
import pandas as pd
import great_expectations as ge
from google.cloud import storage, pubsub_v1

def publish_message(topic_name, message_dict):
    """
    Publie un message JSON sur le topic Pub/Sub désigné.
    """
    project_id = os.environ.get("GCP_PROJECT") or os.environ.get("GOOGLE_CLOUD_PROJECT")
    if not project_id:
        raise Exception("L'ID du projet doit être défini via GCP_PROJECT ou GOOGLE_CLOUD_PROJECT.")
    
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_name)
    
    message_json = json.dumps(message_dict)
    message_bytes = message_json.encode("utf-8")
    
    future = publisher.publish(topic_path, message_bytes)
    logging.info(f"Message publié sur {topic_name} : {message_json}")
    return future.result()

def validate_with_great_expectations(data):
    """
    Utilise Great Expectations pour valider le contenu du CSV.
    Ici, on charge le CSV dans un DataFrame GE et on vérifie par exemple que la colonne 'ResourceID'
    ne contient aucune valeur nulle.
    """
    # Charger le CSV dans un GE DataFrame
    df_ge = ge.read_csv(io.StringIO(data))
    
    # Ajout d'une expectation sur la colonne 'ResourceID'
    expectation_result = df_ge.expect_column_values_to_not_be_null("ResourceID")
    if not expectation_result.get("success", False):
        raise Exception("Validation Great Expectations échouée pour la colonne 'ResourceID'.")
    
    # Tu peux ajouter d'autres expectations ici si nécessaire
    return True

def validate_csv(event, context):
    """
    Fonction déclenchée par l'événement 'finalize' d'un objet dans le bucket Storage.
    Elle télécharge le CSV, effectue plusieurs validations et publie un message Pub/Sub.
    """
    logging.basicConfig(level=logging.INFO)
    
    # Récupérer les variables d'environnement pour les topics Pub/Sub
    success_topic = os.environ.get("SUCCESS_TOPIC")
    error_topic = os.environ.get("ERROR_TOPIC")
    
    if not success_topic or not error_topic:
        logging.error("Les variables d'environnement SUCCESS_TOPIC ou ERROR_TOPIC ne sont pas définies.")
        return
    
    bucket_name = event.get("bucket")
    blob_name = event.get("name")
    
    logging.info(f"Traitement du fichier '{blob_name}' dans le bucket '{bucket_name}'.")
    
    storage_client = storage.Client()
    
    try:
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(blob_name)
        data = blob.download_as_text()
        
        # Lecture du CSV pour vérifier le header
        csv_file = io.StringIO(data)
        reader = csv.reader(csv_file)
        header = next(reader)
        
        required_columns = {"ResourceID", "ResourceName", "ResourceType", "ResourceGroup",
                            "SubscriptionID", "Location", "Tags", "CreatedDate"}
        header_set = set(header)
        
        if not required_columns.issubset(header_set):
            missing = required_columns.difference(header_set)
            error_msg = f"Échec de validation CSV : colonnes manquantes {missing}"
            logging.error(error_msg)
            publish_message(error_topic, {"status": "error", "message": error_msg, "file": blob_name})
            return
        
        # Utiliser Great Expectations pour des tests qualitatifs supplémentaires
        try:
            validate_with_great_expectations(data)
        except Exception as ge_error:
            error_msg = f"Validation GE échouée : {str(ge_error)}"
            logging.error(error_msg)
            publish_message(error_topic, {"status": "error", "message": error_msg, "file": blob_name})
            return
        
        success_msg = f"Le fichier CSV '{blob_name}' a été validé avec succès."
        logging.info(success_msg)
        publish_message(success_topic, {"status": "success", "message": success_msg, "file": blob_name})
    
    except Exception as e:
        error_msg = f"Exception lors du traitement du CSV '{blob_name}' : {str(e)}"
        logging.exception(error_msg)
        publish_message(error_topic, {"status": "error", "message": error_msg, "file": blob_name})
        raise e